package service;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Administrable<T extends CSVSerializable> {

    public void agregar(T evento);

    public T obtener(int indice);

    public void eliminar(int indice);

    public void mostrarTodos();

    public List<T> filtrar(Predicate<T> criterio);

    void ordenarNatural();

    void ordenar(Comparator<T> comparador);

    public void guardarEnBinario(String archivo);

    public void cargarDesdeBinario(String archivo);

    public void guardarEnCSV(String archivo);

    public void cargarDesdeCSV(String path, Function<String,T> funcion);
    
    public void limpiar();
    
}
