package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import modelo.Evento;


public class GestorEventos<T extends Evento & CSVSerializable> implements Administrable<T> {

    private final List<T> inventario = new ArrayList<>();

    @Override
    public void agregar(T evento) {
        if (evento == null) {
            throw new NullPointerException("Elemento nulo");
        }

        inventario.add(evento);
    }

    @Override
    public T obtener(int indice) {
        chequearRangoIndice(indice);

        return inventario.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        chequearRangoIndice(indice);

        inventario.remove(indice);
    }

    @Override
    public void mostrarTodos() {

        inventario.forEach(System.out::println);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrado = new ArrayList<>();

        for (T elemento : inventario) {
            if (criterio.test(elemento)) {
                filtrado.add(elemento);
            }
        }
        return filtrado;
    }

    public List<T> buscarPorRango(LocalDate inicio, LocalDate fin) {
        List<T> resultado = new ArrayList<>();
        for (T evento : inventario) {
            if (evento instanceof Evento e
                    && !e.getFecha().isBefore(inicio)
                    && !e.getFecha().isAfter(fin)) {
                resultado.add(evento);
            }
        }
        return resultado;
    }

    @Override
    public void ordenarNatural() {
        inventario.sort((Comparator<? super T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> criterio) {
        inventario.sort(criterio);
    }

    private void chequearRangoIndice(int indice) {
        if (indice < 0 || indice >= inventario.size()) {
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }

    @Override
    public void guardarEnBinario(String archivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(inventario);
        } catch (IOException e) {
            System.err.println("Error al guardar en binario: " + e.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String archivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            List<T> cargado = (List<T>) ois.readObject();
            inventario.clear();
            inventario.addAll(cargado);
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar desde binario: " + e.getMessage());
        }
    }
    
    @Override
    public void guardarEnCSV(String rutaArchivo) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo))) {
        for (T evento : inventario) {
            writer.write(evento.toCSV());  
            writer.newLine();
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> funcion) {
        limpiar();

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea;

            // Leer y descartar la primera línea (cabecera)
            br.readLine();  // Esto ignora la primera línea que contiene los nombres de las columnas

            while ((linea = br.readLine()) != null) {

                // Verifica si la línea no está vacía
                if (!linea.isEmpty()) {
                    // Usamos la función 'convertidor' pasada como parámetro para convertir la línea en un objeto Animal
                    inventario.add(funcion.apply(linea));

                }
            }
        } catch (IOException ex) {
            System.out.println("Error de lectura: " + ex.getMessage());
            throw new RuntimeException("Error en el archivo");
        }

    }

    @Override
    public void limpiar() {
        inventario.clear();
    }
}
