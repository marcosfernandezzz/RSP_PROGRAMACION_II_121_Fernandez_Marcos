
package service;

@FunctionalInterface
public interface CSVSerializable {
    
    String toCSV(); 
    
}
