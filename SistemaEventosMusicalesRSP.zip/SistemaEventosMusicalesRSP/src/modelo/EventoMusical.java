package modelo;


import java.time.LocalDate;
import service.CSVSerializable;

public class EventoMusical extends Evento implements Comparable<EventoMusical>, CSVSerializable {

    private static final long serialVersionUID = 1L;
    private final String artista;
    private final GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public int compareTo(EventoMusical other) {
        return this.getFecha().compareTo(other.getFecha());
    }

    @Override
    public String toCSV() {
        return getId() + "," + getNombre() + "," + getFecha() + "," + artista + "," + genero;
    }

    public static EventoMusical fromCSV(String linea) {
        String[] partes = linea.split(",");
        
        if (partes.length != 5) {
            throw new IllegalArgumentException("Formato incorrecto: " + linea);
        }
        
        int id = Integer.parseInt(partes[0]);
        String nombre = partes[1];
        LocalDate fecha = LocalDate.parse(partes[2]);
        String artista = partes[3];
        GeneroMusical genero = GeneroMusical.valueOf(partes[4].toUpperCase());
        
        return new EventoMusical(id, nombre, fecha, artista, genero);
    }

    @Override
    public String toString() {
        return "EventoMusical{" + " id=" + getId() + ", nombre='" + getNombre() + "', fecha=" + getFecha() + ", artista='" + artista + "', genero=" + genero + "}";
    }
}
